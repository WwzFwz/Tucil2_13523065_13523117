<h1 align="center">Tugas Kecil 2 IF2211 Strategi Algoritma</h1>
<h3 align="center">Kompresi Gambar dengan Metode Quadtree</h3>


## Table of Contents

- [Description](#description)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Structure](#structure)
- [Getting Started](#getting-started)
- [Contributors](#contributors)
- [References](#references)

## Description


## Features



## Tech Stack
- **xxx**: xxx **xxx** xxx
- **xxx**: xxx **xxx** xxx

## Structure
```
├── README.md
├── src/
│   ├── 
│   └── 
├── test/
│   ├── 
│   ├── 
├── bin/
│   ├── 
|   
└── doc/
```
- src : contains the main program's source code files.
- doc : contains the assignment report.
- test : contains datasets and query fir testing.

## Getting Started
1. **Clone this repository:**
   ```bash
   git clone https://github.com/WwzFwz/Tucil2_13523065_13523117.git
   ```
2. **Navigate to the src directory of the program by running the following command in the terminal:**
   ```bash
   cd Tucil2_13523065_13523117
   ```

### XXX
1. **XXX**
   ```bash
   
   ```


## Contributors

| **NIM**  | **Nama Anggota**               | **Github** |
| -------- | ------------------------------ | ---------- |
| 13523065 | Dzaky Aurelia Fawwaz           | [WwzFwz](https://github.com/WwzFwz) |
| 13523117 | Ferdin Arsenarendra Purtadi    | [Ferdin-Arsenic](https://github.com/Ferdin-Arsenic) |

## References
- [Slide Kuliah 1 IF2211 2024/2025](https://informatika.stei.itb.ac.id/~rinaldi.munir/Stmik/2024-2025/07-Algoritma-Divide-and-Conquer-(2025)-Bagian1.pdf)
- [Slide Kuliah 2 IF2211 2024/2025](https://informatika.stei.itb.ac.id/~rinaldi.munir/Stmik/2024-2025/08-Algoritma-Divide-and-Conquer-(2025)-Bagian2.pdf)
- [Slide Kuliah 3 IF2211 2024/2025](https://informatika.stei.itb.ac.id/~rinaldi.munir/Stmik/2024-2025/09-Algoritma-Divide-and-Conquer-(2025)-Bagian3.pdf)
- [Slide Kuliah 4 IF2211 2024/2025](https://informatika.stei.itb.ac.id/~rinaldi.munir/Stmik/2024-2025/10-Algoritma-Divide-and-Conquer-(2025)-Bagian4.pdf)
- [Spesifikasi Tugas Besar](https://informatika.stei.itb.ac.id/~rinaldi.munir/Stmik/2024-2025/Tucil2-Stima-2025.pdf)
